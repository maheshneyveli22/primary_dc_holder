# springboot-aws-sqs
Amazon SQS ( Simple Queue Service )
