package com.javatechie.aws.sqs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAwsSqsExeApplicationTests {

	@Test
	void contextLoads() {
	}

}
