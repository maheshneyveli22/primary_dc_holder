package com.javatechie.aws.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsElasticbeanstalkExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
