package com.javatechie.aws.ecs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDockerAwsEcsApplicationTests {

	@Test
	void contextLoads() {
	}

}
