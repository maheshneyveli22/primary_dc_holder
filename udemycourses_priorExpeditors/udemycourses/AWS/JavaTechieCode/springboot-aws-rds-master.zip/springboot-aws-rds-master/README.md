# springboot-aws-rds
Amazon Relational Database Service (RDS) Set up, operate, and scale a relational database in the cloud
