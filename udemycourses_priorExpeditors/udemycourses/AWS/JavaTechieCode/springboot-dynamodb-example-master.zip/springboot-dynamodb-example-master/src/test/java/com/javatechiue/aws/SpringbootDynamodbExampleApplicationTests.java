package com.javatechiue.aws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDynamodbExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
