package com.javatechie.aws.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsApigatewayExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
