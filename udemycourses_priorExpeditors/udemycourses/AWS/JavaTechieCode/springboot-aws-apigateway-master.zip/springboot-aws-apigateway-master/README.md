# springboot-aws-apigateway
Access Rest API using API Gateway
