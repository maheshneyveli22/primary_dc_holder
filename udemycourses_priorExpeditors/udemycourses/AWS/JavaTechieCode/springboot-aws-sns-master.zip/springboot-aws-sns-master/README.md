# springboot-aws-sns
Amazon Simple Notification Service Pub/sub messaging for microservices and serverless applications.
