package com.javatechie.aws.rds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAwsRdsExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
