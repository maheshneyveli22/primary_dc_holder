# aws-lambda-api-gateway
Expose a spring cloud function as lambda function in AWS then access it through API Gateway
